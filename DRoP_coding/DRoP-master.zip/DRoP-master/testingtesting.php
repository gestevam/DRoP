<?php
include "classes/class.phpmailer.php"; 
echo 'hi';
$mail = new PHPMailer();
?>
