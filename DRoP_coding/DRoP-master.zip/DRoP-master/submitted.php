print '<meta http-equiv="Refresh" content="0; URL=submitted.php?job=" />';
