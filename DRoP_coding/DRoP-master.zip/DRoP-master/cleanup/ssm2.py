import ssm

ssm.superpose('ND01PRESUPER.pdb', 'ND02PRESUPER.pdb', 'test.pdb')
