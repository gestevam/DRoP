Database offline until further notice.<br/>
Database contents are safe.<br />
If you are shipping crystals, see Paul for ID allocation.<br />
BMK Feb 21, 2011 6:42 PM