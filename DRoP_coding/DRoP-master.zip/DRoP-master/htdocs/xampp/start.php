<?php
	include "langsettings.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler, Kay Vogelgesang, Carsten Wiedmann">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title></title>
	</head>

	<body>
		&nbsp;<br>
	<h1><?=$TEXT['start-head']?>!</h1>
	<b><?=$TEXT['start-subhead']?></b><p>
	

	<?=$TEXT['start-text1']?><p>
	<?=$TEXT['start-text2']?><p>
	<?=$TEXT['start-text3']?><p>
	<?=$TEXT['start-text4']?><p>
	<?=$TEXT['start-text6']?>

	</body>
</html>
